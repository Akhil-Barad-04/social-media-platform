$(document).ready(function () {
  $(".post-pic").change(function () {
    $("#post_picture").submit();
  })
});
